import os
import time
import cv2
import turtle
import numpy as np

# =====
# ==============================

IMAGE_FILE = "maadurga.png"   # Replace this file to trace another image.
MAX_DRAW_WIDTH = 1000
MAX_DRAW_HEIGHT = 650

positions = []
turtle.tracer(0, 0)


def find_closest(p):
    """Return the nearest remaining drawing point to p."""
    if not positions:
        return None
    nodes = np.asarray(positions, dtype=np.float32)
    distances = np.sum((nodes - p) ** 2, axis=1)
    return positions[int(np.argmin(distances))]


def load_and_outline(path):
    """Load the image, scale it for the Turtle window and find its outline."""
    src = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
    if src is None:
        raise FileNotFoundError(f"Could not find image: {path}")

    height, width = src.shape
    scale = min(MAX_DRAW_WIDTH / width, MAX_DRAW_HEIGHT / height, 1.0)
    if scale < 1.0:
        new_size = (max(1, int(width * scale)), max(1, int(height * scale)))
        src = cv2.resize(src, new_size, interpolation=cv2.INTER_AREA)

    blurred = cv2.GaussianBlur(src, (7, 7), 0)
    threshold = cv2.adaptiveThreshold(
        blurred,
        maxValue=255,
        adaptiveMethod=cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        thresholdType=cv2.THRESH_BINARY,
        blockSize=9,
        C=2,
    )
    return threshold


# Locate the image relative to this Python file, so the project works from any folder.
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
image = os.path.join(BASE_DIR, IMAGE_FILE)

th3 = load_and_outline(image)
HEIGHT, WIDTH = th3.shape

# Create a Turtle window that fits the traced image.
screen = turtle.Screen()
screen.title("Lucky -Image Tracer")
screen.setup(width=MAX_DRAW_WIDTH + 80, height=MAX_DRAW_HEIGHT + 120)
screen.bgcolor("white")
screen.setworldcoordinates(
    -WIDTH / 2 - 30,
    -HEIGHT / 2 - 30,
    WIDTH / 2 + 30,
    HEIGHT / 2 + 30,
)

# Get dark pixels from the processed image.
iH, iW = np.where(th3 == 0)
iW = iW - WIDTH / 2
iH = -1 * (iH - HEIGHT / 2)
positions = [list(iwh) for iwh in zip(iW, iH)]

if not positions:
    raise RuntimeError("No drawable outline was detected in the image.")

# Draw with Turtle.
t = turtle.Turtle(visible=False)
t.speed(0)
t.pensize(1)
t.pencolor("gray30")
t.penup()
t.goto(positions[0])
t.pendown()

print(f"Lucky's image tracer started: {WIDTH} x {HEIGHT}")
print(f"Drawing points: {len(positions)}")

time.sleep(1)

p = positions[0]
while p is not None:
    p = find_closest(p)
    if p is None:
        break

    current_pos = np.asarray(t.pos(), dtype=np.float32)
    new_pos = np.asarray(p, dtype=np.float32)
    length = np.linalg.norm(new_pos - current_pos)

    # Smaller gaps are connected; larger gaps start a new stroke.
    cutoff_len = ((WIDTH + HEIGHT) / 2) / 60
    if length < cutoff_len:
        t.goto(p)
    else:
        t.penup()
        t.goto(p)
        t.pendown()

    turtle.update()
    positions.remove(p)

print("Drawing complete. Close the Turtle window to exit.")
turtle.done()
