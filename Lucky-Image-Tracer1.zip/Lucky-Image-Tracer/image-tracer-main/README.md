# Lucky - Krishna Image Tracer

A Python Turtle + OpenCV project that converts an image into a drawable outline and recreates it using Turtle graphics.

## Customized for Lucky

The default input image is the Krishna image stored as `kanji.jpg`.

## Run on Windows

Open Command Prompt inside this folder and run:

```bash
pip install opencv-python numpy
python main.py
```

Python's built-in `turtle` module is used for the drawing window.

## Change the image

Replace `kanji.jpg` with another JPG image, keeping the same filename, and run:

```bash
python main.py
```

The image is automatically scaled to fit the Turtle window while preserving its aspect ratio.
